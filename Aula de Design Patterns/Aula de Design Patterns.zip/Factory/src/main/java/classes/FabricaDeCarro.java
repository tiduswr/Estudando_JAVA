package classes;

public interface FabricaDeCarro {
    public Carro criarCarro();
}
