package classes;

public interface Carro {
    public void showInfo();
}
