package classes;

public class Gol implements Carro {

    @Override
    public void showInfo() {
        System.out.println("{Modelo: Gol; Fabricante: Volks}");
    }

}
