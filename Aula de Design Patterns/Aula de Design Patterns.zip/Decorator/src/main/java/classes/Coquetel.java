package classes;

public abstract class Coquetel {
    protected String nome;
    protected double preco;

    public String getNome() {
        return nome;
    }

    public double getPreco() {
        return preco;
    }
    
}
