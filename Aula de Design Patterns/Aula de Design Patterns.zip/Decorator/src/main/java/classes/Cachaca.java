package classes;

public class Cachaca extends Coquetel{
    public Cachaca(){
        this.nome = "Cachaça";
        this.preco = 2.0f;
    }
}