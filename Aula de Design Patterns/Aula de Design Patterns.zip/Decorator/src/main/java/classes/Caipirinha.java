package classes;

public class Caipirinha extends Coquetel{
    public Caipirinha(){
        this.nome = "Caipirinha";
        this.preco = 4.50f;
    }
}
